#!/usr/bin/env python
# coding: utf-8

# In[179]:


def col_tab(sql_script):
    import re
    d = sql_script.split("from")
    pattern = r'\W+'
    details2 = []
    for i in range(0,len(d)):
        if i == 0:
            details1 =  re.split(pattern,d[i])
        if i>=1:
            details2.append(re.split(pattern,d[i]))

    column = {}        
    for i in range(len(details1)):
        #print(details1[i])
        if len(details1[i]) == 1:
            column[details1[i]] = details1[i+1]

    table = {}        
    for i in range(len(details2)):
        #print(details2[i])
        for j in range(len(details2[i])):
            if len(details2[i][j]) == 1:
                table[details2[i][j]]=details2[i][j-1]

    return table,column   


# In[180]:


sql_script = "select a.uid, b.unamefrom (select * from user) a,(select * from user_details) b"


# In[181]:


table,column = col_tab(sql_script)


# In[182]:


print(table,column)

